// متغيرات لتخزين البيانات الإجمالية
let totalLitres = 0;
let totalRevenue = 0;

// تعريف كائن لتخزين المبيعات لكل مركز
let centers = {
    center1: { litres: 0, revenue: 0 },
    center2: { litres: 0, revenue: 0 },
    center3: { litres: 0, revenue: 0 },
    center4: { litres: 0, revenue: 0 },
    center5: { litres: 0, revenue: 0 },
    center6: { litres: 0, revenue: 0 },
    center7: { litres: 0, revenue: 0 },
    center8: { litres: 0, revenue: 0 },
    center9: { litres: 0, revenue: 0 },
    center10: { litres: 0, revenue: 0 },
};

// تحديث دالة الحساب
function calculate() {
    const center = document.getElementById("center").value;
    const fuelType = document.getElementById("fuelType").value;
    const fuelPrice = parseFloat(document.getElementById("fuelPrice").value) || 0;
    const startMeter = parseFloat(document.getElementById("startMeter").value) || 0;
    const endMeter = parseFloat(document.getElementById("endMeter").value) || 0;

    if (endMeter < startMeter) {
        alert("الرجاء إدخال قيم صحيحة للعدادات.");
        return;
    }

    // حساب اللترات المباعة
    const litresSold = endMeter - startMeter;
    const totalAmount = litresSold * fuelPrice;

    // تحديث النتائج في الواجهة
    document.getElementById("litresSold").value = litresSold.toFixed(2) + " لتر";
    document.getElementById("totalAmount").value = totalAmount.toFixed(2) + " درهم";

    // إضافة اللترات والمبلغ للمركز المحدد
    centers[center].litres += litresSold;
    centers[center].revenue += totalAmount;

    // إضافة اللترات والمبلغ للإجمالي
    totalLitres += litresSold;
    totalRevenue += totalAmount;

    // تحديث إجمالي المبيعات لجميع المراكز
    document.getElementById("totalLitres").value = totalLitres.toFixed(2) + " لتر";
    document.getElementById("totalRevenue").value = totalRevenue.toFixed(2) + " درهم";

    // تحديث المبيعات لكل مركز
    updateCenterTotals();
}

// دالة لتحديث المبيعات لكل مركز
function updateCenterTotals() {
    for (let center in centers) {
        document.getElementById(center + "Total").value = `${centers[center].litres.toFixed(2)} لتر - ${centers[center].revenue.toFixed(2)} درهم`;
    }
}

// دالة لإعادة تعيين جميع الحقول
function resetAll() {
    // إعادة تعيين جميع الحقول
    document.getElementById("fuelPrice").value = '';
    document.getElementById("startMeter").value = '';
    document.getElementById("endMeter").value = '';
    document.getElementById("litresSold").value = '';
    document.getElementById("totalAmount").value = '';
    document.getElementById("totalLitres").value = '';
    document.getElementById("totalRevenue").value = '';

    // إعادة تعيين المبيعات لكل مركز
    for (let center in centers) {
        centers[center].litres = 0;
        centers[center].revenue = 0;
    }

    updateCenterTotals();
}